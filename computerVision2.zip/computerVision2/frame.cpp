#include "frame.hpp"

Frame::Frame() : wxFrame(0, wxID_ANY, wxT("Counter"))
{
	wxInitAllImageHandlers();

	this->SetBackgroundColour(wxColor(240,240,240));

	sizer = new wxBoxSizer(wxVERTICAL);

	sizerFileOpen = new wxBoxSizer(wxHORIZONTAL);

	buttonFileSelect = new wxButton(this, wxID_ANY, wxT("Durchsuchen"), wxDefaultPosition, wxSize(100, -1));
	buttonFileOpen = new wxButton(this, wxID_ANY, wxT("Öffnen"), wxDefaultPosition, wxSize(100, -1));

	textFilePath = new wxTextCtrl(this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize(200, -1));



	image = new wxImage();

	sizerFileOpen->Add(textFilePath, 0, 0, 15);
	sizerFileOpen->Add(buttonFileSelect, 0, 0, 15);

	sizer->Add(sizerFileOpen, 0, 0, 15);
	sizer->Add(buttonFileOpen, 0, 0, 15);

	this->SetSizer(sizer);
	this->Layout();

	buttonFileSelect->Connect(wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Frame::OnHitButtonFileSelect ), NULL, this);
	buttonFileOpen->Connect(wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Frame::OnHitButtonFileOpen ), NULL, this);
}

Frame::~Frame()
{

}

void Frame::OnHitButtonFileSelect(wxCommandEvent& event)
{
	wxFileDialog* fileDialog;
	fileDialog = new wxFileDialog
							(this,
							wxT("Datei öffnen"),
							wxT(""),
							wxT(""),
							wxT(""),
							wxFD_MULTIPLE
							);

//	fileDialog->SetWildcard(wxT("TIFF-Dateien (*.tif, *.tiff)|*.tif?"));

	fileDialog->ShowModal();

	wxArrayString* stringsFiles;
	stringsFiles = new wxArrayString();

	fileDialog->GetPaths(*stringsFiles);

	textFilePath->SetValue(stringsFiles->Item(0));
}

void Frame::OnHitButtonFileOpen(wxCommandEvent& event)
{
	wxImage *srcImage;
	srcImage = new wxImage(textFilePath->GetValue());

	unsigned char* imageData = srcImage->GetData();

	int imageHeight = srcImage->GetHeight();
	int imageWidth = srcImage->GetWidth();

	//Falsche Bildgröße
	if(imageHeight != 450 || imageWidth != 799)
	{
		wxMessageDialog *errorDialog;
		errorDialog = new wxMessageDialog(this, wxT("Falsche Bildabmessung Erfordert: 1597x900"), wxT("Fehler"), wxOK);
		errorDialog->ShowModal();

		image->Destroy();

		return;
	}

	//Ad an array for colors with the Pixels of the image
	Color imageColors[799][450];


	wxImage *calcImage;
	calcImage = new wxImage(imageWidth, imageHeight);

	//for(int z=0 ; z<200 ; z++)
	//{

	//Farbwerte für Array berechnen
	for(int x = 0 ; x<imageWidth ; x++)
	{
		for(int y = 0 ; y<imageHeight ; y++)
		{
			float min, max, delta;

			float h = 0, s, v;

			float r, g, b;

			//RGB werte holen
			r = *(imageData + y*imageWidth*3 + 3*x);
			g = *(imageData + y*imageWidth*3 + 3*x+1);
			b = *(imageData + y*imageWidth*3 + 3*x+2);

			//Tonwertkorektur anwenden
			int up = 220;
			int down = 40;
			int dif = up - down;

			float faktor = 255.0/dif;

			r = (r - down);
			if(r < 0) r = 0;
			r *= faktor;
			if(r > 255) r = 255;
			r /= 255.0;

			g = (g - down);
			if(g < 0) g = 0;
			g *= faktor;
			if(g > 255) g = 255;
			g /= 255.0;

			b = (b - down);
			if(b < 0) b = 0;
			b *= faktor;
			if(b > 255) b = 255;
			b /= 255.0;

			max = r;
			if(g > max) max = g;
			if(b > max) max = b;

			min = r;
			if(g < min) min = g;
			if(b < min) min = b;

			delta = max - min;


			//calculate H
			if(max==min) h=0;
			else if(max==r) h=60*((g-b)/delta);
			else if(max==g) h=60*(2+(b-r)/delta);
			else if(max==b) h=60*(4+(r-g)/delta);


			//calculate S
			if(max==0) s=0;
			else s=delta/max;

			//calculate V
			v=max;

			//make s, v to percent
			s *= 100;
			v *= 100;

			//Zum Debug HSV abspeichern
			calcImage->SetRGB(x, y, h/2, s/2, v/2);
			//calcImage->SetRGB(x, y, r*255, g*255, b*255);

			//Farbwerte ermitteln
			if(h>110 && h<150 && v>25) imageColors[x][y]=green;
			else if(h>190 && h<215 && v>28) imageColors[x][y]=blue;
			else if(h>30 && h<50 && v>40 && s>50) imageColors[x][y]=yellow;
			else if(v<25) imageColors[x][y]=black;
			else imageColors[x][y]=undefined;
		}
	}

	//remove Errors

	for(int x=1 ; x<(imageWidth-1) ; x++)
	{
		for(int y=1 ; y<(imageHeight-1) ; y++)
		{
			int count[maxColorSize] = {0};

			count[imageColors[x-1][y-1]]++;
			count[imageColors[x][y-1]]++;
			count[imageColors[x+1][y-1]]++;
			count[imageColors[x-1][y]]++;
			count[imageColors[x+1][y]]++;
			count[imageColors[x-1][y+1]]++;
			count[imageColors[x][y+1]]++;
			count[imageColors[x+1][y+1]]++;

			if(count[imageColors[x][y]] < 4)
			{
				int max=0;
				int maxPos=0;

				for(int i=0 ; i<maxColorSize ; i++)
				{
					if(count[i]>max)
					{
						max=count[i];
						maxPos=i;
					}
				}

				imageColors[x][y]=(Color)maxPos;
			}


		}

	}


	//}

	//Ergebnissbild erstellen
	wxImage *resImage;
	resImage = new wxImage(imageWidth, imageHeight);

	for(int x = 0 ; x<imageWidth ; x++)
	{
		for(int y = 0 ; y<imageHeight ; y++)
		{
			switch(imageColors[x][y])
			{
				case green:
					resImage->SetRGB(x, y, 0, 180, 0);break;
				case blue:
					resImage->SetRGB(x, y, 0, 0, 180);break;
				case yellow:
					resImage->SetRGB(x, y, 220, 220, 0);break;
				case black:
					resImage->SetRGB(x, y, 0, 0, 0);break;
				default:
					resImage->SetRGB(x, y, 128, 128, 128);break;
			}
		}
	}







	//save calculation image
	calcImage->SaveFile(textFilePath->GetValue()+wxT(".calc.tif"));

	//save result image
	resImage->SaveFile(textFilePath->GetValue()+wxT(".result.tif"));

	//Fertig Box anzeigen
	wxMessageDialog *readyDialog;
	readyDialog = new wxMessageDialog(this, wxT("Speichern abgeschlossen"), wxT("Fertig!"), wxOK);
	readyDialog->ShowModal();

	//Bild löschen
	srcImage->Destroy();
	calcImage->Destroy();
	resImage->Destroy();
}
