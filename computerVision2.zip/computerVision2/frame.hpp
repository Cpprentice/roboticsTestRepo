#ifndef FRAME_HPP
#define FRAME_HPP

#include <wx/wx.h>
#include <wx/progdlg.h>

#include "Color.hpp"

class Frame : public wxFrame {
	public:
		Frame();
		~Frame();

	private:

		wxSizer* sizer;
		wxSizer* sizerFileOpen;

		wxButton* buttonFileSelect;
		wxButton* buttonFileOpen;

		wxTextCtrl* textFilePath;

//		wxStaticBitmap* staticBitmapShow;

		wxImage* image;

		void OnHitButtonFileSelect(wxCommandEvent& event);
		void OnHitButtonFileOpen(wxCommandEvent& event);
};



#endif
