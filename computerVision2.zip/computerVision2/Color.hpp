#ifndef COLOR_HPP
#define COLOR_HPP

enum Color {undefined, green, blue, yellow, black, maxColorSize};

#endif // COLOR_HPP
